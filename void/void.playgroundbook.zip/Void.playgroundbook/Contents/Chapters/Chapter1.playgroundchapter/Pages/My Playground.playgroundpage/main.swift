print("☑️")
